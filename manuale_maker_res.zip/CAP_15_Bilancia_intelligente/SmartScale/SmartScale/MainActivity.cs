﻿using Android.App;
using Android.Widget;
using Android.OS;
using System;
using Android.Bluetooth;
using System.Linq;

namespace SmartScale
{
    [Activity(Label = "SmartScale", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        BluetoothConnection myConnection = new BluetoothConnection();


        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            SetContentView(Resource.Layout.Main);

            Button buttonConnect = FindViewById<Button>(Resource.Id.button1);
            Button buttonDisconnect = FindViewById<Button>(Resource.Id.button2);

                         
            TextView connected = FindViewById<TextView>(Resource.Id.textView1);
            TextView peso = FindViewById<TextView>(Resource.Id.textView2);

            BluetoothSocket _socket = null;

            System.Threading.Thread listenThread = new System.Threading.Thread(listener);
            listenThread.Abort();

            buttonConnect.Click += delegate {


                ////////////////////////////////////////////////
                listenThread.Start();

                myConnection = new BluetoothConnection();

                myConnection.getAdapter();

                myConnection.thisAdapter.StartDiscovery();

                try
                {

                    myConnection.getDevice();
                    myConnection.thisDevice.SetPairingConfirmation(false);
                    myConnection.thisDevice.SetPairingConfirmation(true);
                    myConnection.thisDevice.CreateBond();


                }
                catch 
                {
                }

                myConnection.thisAdapter.CancelDiscovery();


                _socket = myConnection.thisDevice.CreateRfcommSocketToServiceRecord(Java.Util.UUID.FromString("00001101-0000-1000-8000-00805f9b34fb"));

                myConnection.thisSocket = _socket;

                try
                {
                    myConnection.thisSocket.Connect();

                    connected.Text = "Connected!";
                    buttonDisconnect.Enabled = true;
                    buttonConnect.Enabled = false;

                    if (listenThread.IsAlive == false)
                    {
                        listenThread.Start();
                    }

                }
                catch 
                {

                }


            };

            buttonDisconnect.Click += delegate {

                try
                {
                    buttonConnect.Enabled = true;
                    listenThread.Abort();

                    myConnection.thisDevice.Dispose();

                    myConnection.thisSocket.Close();

                    myConnection = new BluetoothConnection();
                    _socket = null;

                    connected.Text = "Disconnected";
                }
                catch { }
            };


            

           

            



            



            
        }

        void listener()
        {
            byte[] read = new byte[1];



            while (true)
            {

                try
                {

                    myConnection.thisSocket.InputStream.Read(read, 0, 1);
                    myConnection.thisSocket.InputStream.Close();
                    RunOnUiThread(() =>
                    {

                        if (read[0] == 1)
                        {

                            // readTextView.Text = "Relais ON";

                        }
                        else if (read[0] == 0)
                        {
                            //readTextView.Text = "Relais OFF";                                

                        }

                    });
                }
                catch { }

            }
        }

    }
    public class BluetoothConnection
    {

        public void getAdapter() { this.thisAdapter = BluetoothAdapter.DefaultAdapter; }
        public void getDevice() { this.thisDevice = (from bd in this.thisAdapter.BondedDevices where bd.Name == "HC-05" select bd).FirstOrDefault(); }

        public BluetoothAdapter thisAdapter { get; set; }
        public BluetoothDevice thisDevice { get; set; }
        public BluetoothSocket thisSocket { get; set; }

    }
}

