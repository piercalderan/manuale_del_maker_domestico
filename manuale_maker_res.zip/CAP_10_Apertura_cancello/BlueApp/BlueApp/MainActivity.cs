﻿using Android.App;
using Android.Widget;
using Android.OS;
using Android.Bluetooth;
using System.Linq;

namespace BlueApp
{
    [Activity(Label = "BlueApp", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity        
    {

        BluetoothConnection myConnection = new BluetoothConnection();
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            SetContentView(Resource.Layout.Main);
            Button buttonConnect = FindViewById<Button>(Resource.Id.button1);
            Button buttonDisconnect = FindViewById<Button>(Resource.Id.button2);
            Button buttonOn = FindViewById<Button>(Resource.Id.button3);
            Button buttonOff = FindViewById<Button>(Resource.Id.button4);
            TextView connected = FindViewById<TextView>(Resource.Id.textView2);
            BluetoothSocket _socket = null;

            buttonConnect.Click += delegate {
                myConnection = new BluetoothConnection();
                myConnection.getAdapter();
                myConnection.thisAdapter.StartDiscovery();

                try
                {

                    myConnection.getDevice();
                    myConnection.thisDevice.SetPairingConfirmation(false);

                    myConnection.thisDevice.SetPairingConfirmation(true);
                    myConnection.thisDevice.CreateBond();


                }
                catch { }

                myConnection.thisAdapter.CancelDiscovery();
                _socket = myConnection.thisDevice.CreateRfcommSocketToServiceRecord(Java.Util.UUID.FromString("00001101-0000-1000-8000-00805f9b34fb"));
                myConnection.thisSocket = _socket;

                try
                {
                    myConnection.thisSocket.Connect();
                    connected.Text = "Connected!";
                    buttonDisconnect.Enabled = true;
                    buttonConnect.Enabled = false;

                }
                catch { }
            };

            buttonDisconnect.Click += delegate {
                try
                {
                    buttonConnect.Enabled = true;
                    myConnection.thisDevice.Dispose();
                    myConnection.thisSocket.OutputStream.WriteByte(187);
                    myConnection.thisSocket.OutputStream.Close();
                    myConnection.thisSocket.Close();
                    myConnection = new BluetoothConnection();
                    _socket = null;
                    connected.Text = "Disconnected!";
                }
                catch { }
            };

            buttonOn.Click += delegate {
                try
                {
                    myConnection.thisSocket.OutputStream.WriteByte(1);
                    myConnection.thisSocket.OutputStream.WriteByte(1);
                    myConnection.thisSocket.OutputStream.WriteByte(1);
                    myConnection.thisSocket.OutputStream.Close();
                }
                catch { }
            };

            buttonOff.Click += delegate {
                try
                {
                    myConnection.thisSocket.OutputStream.WriteByte(0);
                    myConnection.thisSocket.OutputStream.WriteByte(0);
                    myConnection.thisSocket.OutputStream.WriteByte(0);
                    myConnection.thisSocket.OutputStream.Close();
                }
                catch { }
            };
        }
    }
    public class BluetoothConnection
    {
        public void getAdapter() { this.thisAdapter = BluetoothAdapter.DefaultAdapter; }
        public void getDevice() { this.thisDevice = (from bd in this.thisAdapter.BondedDevices where bd.Name == "HC-05" select bd).FirstOrDefault(); }
        public BluetoothAdapter thisAdapter { get; set; }
        public BluetoothDevice thisDevice { get; set; }
        public BluetoothSocket thisSocket { get; set; }
    }
}

