#! /usr/local/bin/python
import sys
import os
import re
from smtplib import SMTP_SSL as SMTP       
from email.mime.text import MIMEText
from email.MIMEMultipart import MIMEMultipart
from email.MIMEBase import MIMEBase
from email import Encoders

SMTPserver = 'smtps.aruba.it'
sender =     'sender@email.com'
destination = 'dest@email.com'
USERNAME = "MyUSERNAME"
PASSWORD = "MyPASSWORD"
text_subtype = 'plain'
content="""Messaggio"""
subject="Allarme"

msg = MIMEMultipart()

def email_send():
        try:
                
                msg['Subject']= subject
                msg['From'] = sender
                msg.attach(part)
                conn = SMTP(SMTPserver)
                conn.set_debuglevel(False)
                conn.login(USERNAME, PASSWORD)
                try:
                        conn.sendmail(sender, destination, msg.as_string())
                        print("Invio eseguito")
                finally:
                        conn.quit()
        except Exception: print("Invio fallito")

from picamera.array import PiRGBArray
from picamera import PiCamera
import argparse
import warnings
import datetime
import imutils
import json
import time
import cv2
import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(26,GPIO.OUT)

warnings.filterwarnings("ignore")
conf = json.load(open('configurazione.json'))
client = None

camera = PiCamera()
camera.resolution = tuple(conf["resolution"])
camera.framerate = conf["fps"]
rawCapture = PiRGBArray(camera, size=tuple(conf["resolution"]))
count = 0
motionFlag = False
avg = None
motionCounter = 0
lastUploaded = datetime.datetime.now()
print "Avvio..."
time.sleep(2)

for f in camera.capture_continuous(rawCapture, format="bgr", use_video_port=True):
        frame = f.array
        timestamp = datetime.datetime.now()
        text = "Nessun movimento"
        motionFlag = False
        frame = imutils.resize(frame, width=500)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.GaussianBlur(gray, (21, 21), 0)
        if avg is None:
                
                avg = gray.copy().astype("float")
                rawCapture.truncate(0)
                continue

        cv2.accumulateWeighted(gray, avg, 0.5)
        frameDelta = cv2.absdiff(gray, cv2.convertScaleAbs(avg))

        thresh = cv2.threshold(frameDelta, conf["threshold"], 255, cv2.THRESH_BINARY)[1]
        thresh = cv2.dilate(thresh, None, iterations=2)
        (cnts, _) = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        for c in cnts:
                if cv2.contourArea(c) < conf["min_area"]:
                        continue
                (x, y, w, h) = cv2.boundingRect(c)
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
                text = "Movimento rilevato"
                motionFlag = True
        ts = timestamp.strftime("%A %d %B %Y %I:%M:%S%p")
        cv2.putText(frame, "Stato attuale: {}".format(text), (10, 20), cv2.FONT_HERSHEY_PLAIN, 1.5, (255, 255, 255), 2)
        cv2.putText(frame, ts, (10, frame.shape[0] - 10), cv2.FONT_HERSHEY_PLAIN, 1, (255, 255, 255), 1)

        if motionFlag == True:
                
                if (timestamp - lastUploaded).seconds >= conf["min_time"]:
                        motionCounter += 1

                        if motionCounter >= conf["min_motion"]:
                                if conf["use_img"]:
                                        count += 1
                                        t = 'foto_' + str(count) + '.jpg'
                                        cv2.imwrite(t, frame)

                                        if conf["use_email"]:
                                                part = MIMEBase('application', "octet-stream")
                                                attach=open(t,"rb")
                                                
                                                part.set_payload(attach.read())
                                                Encoders.encode_base64(part)
                                                part.add_header('Content-Disposition', 'attachment; filename='+t)
                                                email_send()                                                
                                                #part.set_payload(attach.close())
                                GPIO.output(26,GPIO.HIGH)                                        
                                print "LED ON"
                                lastUploaded = timestamp
                                motionCounter = 0
                                
        else:
                print "LED OFF"
                GPIO.output(26,GPIO.LOW)                
                motionCounter = 0

        if conf["video_preview"]:
                cv2.imshow("Videocamera di sicurezza", frame)
                key = cv2.waitKey(1) & 0xFF
                
        rawCapture.truncate(0)
